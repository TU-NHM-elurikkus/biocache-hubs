
//= require jquery_i18n
//= require leaflet-0.7.2/leaflet.js
