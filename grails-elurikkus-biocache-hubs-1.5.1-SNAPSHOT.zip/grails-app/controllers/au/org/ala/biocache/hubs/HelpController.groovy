package au.org.ala.biocache.hubs

class HelpController {

    def index() {
        redirect(action: 'help')
    }

    def help() {}
    def data() {}
    def termsOfUse() {}
}
