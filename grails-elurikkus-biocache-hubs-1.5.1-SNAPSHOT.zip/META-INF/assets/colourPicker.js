/*
 * // require jquery
//= require jquery.colourPicker.js
 */