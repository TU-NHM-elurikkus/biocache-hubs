
//= require jquery_migration
//= require jquery.i18n.properties-1.0.9.min

 
 