/*
 * // require jquery
//= require purl
//= require jquery_i18n
//= require jquery.cookie.js
//= require jquery.inview.min.js
//= require jquery.jsonp-2.4.0.min.js
 */
 