/*
 * // require jquery
//= require purl
//= require magellan
//= require yourAreaMap
 */
