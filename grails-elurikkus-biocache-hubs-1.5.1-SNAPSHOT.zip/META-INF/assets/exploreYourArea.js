/*
 * // require jquery
//= require purl
//= require magellan.js
//= require yourAreaMap.js
 */