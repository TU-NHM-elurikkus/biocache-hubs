/*
 * // require jquery
//= require jquery.colourPicker
 */
